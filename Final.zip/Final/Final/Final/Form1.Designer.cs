﻿
namespace Final
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.label1 = new System.Windows.Forms.Label();
            this.cbx_MosType = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_Qox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_tox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_Parameter4 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_Parameter3 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_Parameter2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_Parameter1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_Er = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbx_OxideMaterial = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_Dopant = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_Ef = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbx_GateMartial = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbx_NPtype = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Vt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cbx_Output = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btn = new System.Windows.Forms.Button();
            this.cht_IdVd = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.cht_IdVg = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.cht_CVg = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label34 = new System.Windows.Forms.Label();
            this.txt_gm = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cht_IdVd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cht_IdVg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cht_CVg)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "半導體類型";
            // 
            // cbx_MosType
            // 
            this.cbx_MosType.FormattingEnabled = true;
            this.cbx_MosType.Items.AddRange(new object[] {
            "MOSFET",
            "FinFET"});
            this.cbx_MosType.Location = new System.Drawing.Point(127, 20);
            this.cbx_MosType.Name = "cbx_MosType";
            this.cbx_MosType.Size = new System.Drawing.Size(121, 26);
            this.cbx_MosType.TabIndex = 1;
            this.cbx_MosType.SelectedIndexChanged += new System.EventHandler(this.cbx_MosType_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.txt_Qox);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txt_tox);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txt_Parameter4);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txt_Parameter3);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txt_Parameter2);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txt_Parameter1);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txt_Er);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.cbx_OxideMaterial);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txt_Dopant);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txt_Ef);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cbx_GateMartial);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cbx_NPtype);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(12, 66);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(455, 531);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Design Parameter";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(224, 140);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(63, 18);
            this.label23.TabIndex = 20;
            this.label23.Text = "cm^(-3)";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(262, 392);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(27, 18);
            this.label22.TabIndex = 20;
            this.label22.Text = "uC";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(224, 495);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(29, 18);
            this.label21.TabIndex = 20;
            this.label21.Text = "nm";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(251, 341);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 18);
            this.label20.TabIndex = 20;
            this.label20.Text = "nm";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(239, 291);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 18);
            this.label19.TabIndex = 20;
            this.label19.Text = "nm";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(244, 239);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 18);
            this.label18.TabIndex = 19;
            this.label18.Text = "nm";
            // 
            // txt_Qox
            // 
            this.txt_Qox.Location = new System.Drawing.Point(151, 388);
            this.txt_Qox.Name = "txt_Qox";
            this.txt_Qox.Size = new System.Drawing.Size(105, 29);
            this.txt_Qox.TabIndex = 23;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(11, 392);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(134, 18);
            this.label17.TabIndex = 22;
            this.label17.Text = "氧化層容許電荷";
            // 
            // txt_tox
            // 
            this.txt_tox.Location = new System.Drawing.Point(140, 337);
            this.txt_tox.Name = "txt_tox";
            this.txt_tox.Size = new System.Drawing.Size(105, 29);
            this.txt_tox.TabIndex = 21;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(11, 341);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(123, 18);
            this.label16.TabIndex = 20;
            this.label16.Text = "Oxide Thickness";
            // 
            // txt_Parameter4
            // 
            this.txt_Parameter4.Location = new System.Drawing.Point(113, 491);
            this.txt_Parameter4.Name = "txt_Parameter4";
            this.txt_Parameter4.Size = new System.Drawing.Size(105, 29);
            this.txt_Parameter4.TabIndex = 23;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(11, 495);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(93, 18);
            this.label14.TabIndex = 22;
            this.label14.Text = "Gate Length";
            // 
            // txt_Parameter3
            // 
            this.txt_Parameter3.Location = new System.Drawing.Point(133, 437);
            this.txt_Parameter3.Name = "txt_Parameter3";
            this.txt_Parameter3.Size = new System.Drawing.Size(105, 29);
            this.txt_Parameter3.TabIndex = 21;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 441);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(116, 18);
            this.label13.TabIndex = 20;
            this.label13.Text = "Numbers of Fin";
            // 
            // txt_Parameter2
            // 
            this.txt_Parameter2.Location = new System.Drawing.Point(128, 287);
            this.txt_Parameter2.Name = "txt_Parameter2";
            this.txt_Parameter2.Size = new System.Drawing.Size(105, 29);
            this.txt_Parameter2.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 291);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 18);
            this.label12.TabIndex = 18;
            this.label12.Text = "Channel Width";
            // 
            // txt_Parameter1
            // 
            this.txt_Parameter1.Location = new System.Drawing.Point(133, 235);
            this.txt_Parameter1.Name = "txt_Parameter1";
            this.txt_Parameter1.Size = new System.Drawing.Size(105, 29);
            this.txt_Parameter1.TabIndex = 17;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(11, 239);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(116, 18);
            this.label11.TabIndex = 16;
            this.label11.Text = "Channel Length";
            // 
            // txt_Er
            // 
            this.txt_Er.Location = new System.Drawing.Point(338, 187);
            this.txt_Er.Name = "txt_Er";
            this.txt_Er.Size = new System.Drawing.Size(54, 29);
            this.txt_Er.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(252, 191);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 18);
            this.label8.TabIndex = 10;
            this.label8.Text = "介電系數";
            // 
            // cbx_OxideMaterial
            // 
            this.cbx_OxideMaterial.FormattingEnabled = true;
            this.cbx_OxideMaterial.Items.AddRange(new object[] {
            "SiO2",
            "HighK",
            "Other"});
            this.cbx_OxideMaterial.Location = new System.Drawing.Point(113, 187);
            this.cbx_OxideMaterial.Name = "cbx_OxideMaterial";
            this.cbx_OxideMaterial.Size = new System.Drawing.Size(121, 26);
            this.cbx_OxideMaterial.TabIndex = 8;
            this.cbx_OxideMaterial.SelectedIndexChanged += new System.EventHandler(this.cbx_OxideMaterial_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 191);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 18);
            this.label9.TabIndex = 9;
            this.label9.Text = "氧化層材料";
            // 
            // txt_Dopant
            // 
            this.txt_Dopant.Location = new System.Drawing.Point(113, 136);
            this.txt_Dopant.Name = "txt_Dopant";
            this.txt_Dopant.Size = new System.Drawing.Size(105, 29);
            this.txt_Dopant.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(398, 93);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 18);
            this.label6.TabIndex = 6;
            this.label6.Text = "eV";
            // 
            // txt_Ef
            // 
            this.txt_Ef.Location = new System.Drawing.Point(338, 89);
            this.txt_Ef.Name = "txt_Ef";
            this.txt_Ef.Size = new System.Drawing.Size(54, 29);
            this.txt_Ef.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(244, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 18);
            this.label5.TabIndex = 5;
            this.label5.Text = "Fermi level";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "Well Dopant";
            // 
            // cbx_GateMartial
            // 
            this.cbx_GateMartial.FormattingEnabled = true;
            this.cbx_GateMartial.Items.AddRange(new object[] {
            "nPolySi",
            "pPolySi",
            "Al",
            "W",
            "Other"});
            this.cbx_GateMartial.Location = new System.Drawing.Point(97, 89);
            this.cbx_GateMartial.Name = "cbx_GateMartial";
            this.cbx_GateMartial.Size = new System.Drawing.Size(121, 26);
            this.cbx_GateMartial.TabIndex = 4;
            this.cbx_GateMartial.SelectedIndexChanged += new System.EventHandler(this.cbx_GateMartial_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "閘極材料";
            // 
            // cbx_NPtype
            // 
            this.cbx_NPtype.FormattingEnabled = true;
            this.cbx_NPtype.Items.AddRange(new object[] {
            "N Type",
            "P Type"});
            this.cbx_NPtype.Location = new System.Drawing.Point(97, 40);
            this.cbx_NPtype.Name = "cbx_NPtype";
            this.cbx_NPtype.Size = new System.Drawing.Size(121, 26);
            this.cbx_NPtype.TabIndex = 3;
            this.cbx_NPtype.SelectedIndexChanged += new System.EventHandler(this.cbx_NPtype_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "元件類型";
            // 
            // txt_Vt
            // 
            this.txt_Vt.Location = new System.Drawing.Point(1144, 20);
            this.txt_Vt.Name = "txt_Vt";
            this.txt_Vt.Size = new System.Drawing.Size(96, 29);
            this.txt_Vt.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1003, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 18);
            this.label7.TabIndex = 13;
            this.label7.Text = "Threshold Voltage";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1246, 24);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 18);
            this.label10.TabIndex = 15;
            this.label10.Text = "Volt";
            // 
            // cbx_Output
            // 
            this.cbx_Output.FormattingEnabled = true;
            this.cbx_Output.Items.AddRange(new object[] {
            "Id-Vd",
            "Id-Vg",
            "C-Vg"});
            this.cbx_Output.Location = new System.Drawing.Point(614, 20);
            this.cbx_Output.Name = "cbx_Output";
            this.cbx_Output.Size = new System.Drawing.Size(121, 26);
            this.cbx_Output.TabIndex = 17;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(510, 24);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 18);
            this.label15.TabIndex = 16;
            this.label15.Text = "Plotting Type";
            // 
            // btn
            // 
            this.btn.Location = new System.Drawing.Point(820, 17);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(96, 29);
            this.btn.TabIndex = 18;
            this.btn.Text = "Output";
            this.btn.UseVisualStyleBackColor = true;
            this.btn.Click += new System.EventHandler(this.btn_Click);
            // 
            // cht_IdVd
            // 
            chartArea1.Name = "ChartArea1";
            this.cht_IdVd.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.cht_IdVd.Legends.Add(legend1);
            this.cht_IdVd.Location = new System.Drawing.Point(492, 71);
            this.cht_IdVd.Name = "cht_IdVd";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Vg=0.5V";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.Name = "Vg=1.0V";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Legend = "Legend1";
            series3.Name = "Vg=1.5V";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Legend = "Legend1";
            series4.Name = "Vg=2.0V";
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series5.Legend = "Legend1";
            series5.Name = "Vg=2.5V";
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series6.Legend = "Legend1";
            series6.Name = "Vg=3.0V";
            this.cht_IdVd.Series.Add(series1);
            this.cht_IdVd.Series.Add(series2);
            this.cht_IdVd.Series.Add(series3);
            this.cht_IdVd.Series.Add(series4);
            this.cht_IdVd.Series.Add(series5);
            this.cht_IdVd.Series.Add(series6);
            this.cht_IdVd.Size = new System.Drawing.Size(748, 526);
            this.cht_IdVd.TabIndex = 19;
            this.cht_IdVd.Text = "chart1";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(1498, 75);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(38, 18);
            this.label24.TabIndex = 22;
            this.label24.Text = "Volt";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(1396, 71);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(96, 29);
            this.textBox1.TabIndex = 21;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(1255, 75);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(129, 18);
            this.label25.TabIndex = 20;
            this.label25.Text = "FlatBand Voltage";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(1498, 128);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(38, 18);
            this.label26.TabIndex = 25;
            this.label26.Text = "Volt";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(1396, 124);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(96, 29);
            this.textBox2.TabIndex = 24;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(1255, 128);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(134, 18);
            this.label27.TabIndex = 23;
            this.label27.Text = "Depletion Voltage";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(1498, 180);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(38, 18);
            this.label28.TabIndex = 28;
            this.label28.Text = "Volt";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(1396, 176);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(96, 29);
            this.textBox3.TabIndex = 27;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(1255, 180);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(123, 18);
            this.label29.TabIndex = 26;
            this.label29.Text = "Reverse Voltage";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(1498, 234);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(38, 18);
            this.label30.TabIndex = 31;
            this.label30.Text = "Volt";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(1396, 230);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(96, 29);
            this.textBox4.TabIndex = 30;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(1255, 234);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(55, 18);
            this.label31.TabIndex = 29;
            this.label31.Text = "Phi ms";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(1498, 285);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(38, 18);
            this.label32.TabIndex = 34;
            this.label32.Text = "Volt";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(1396, 281);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(96, 29);
            this.textBox5.TabIndex = 33;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(1255, 285);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(74, 18);
            this.label33.TabIndex = 32;
            this.label33.Text = "-Qox/Cox";
            // 
            // cht_IdVg
            // 
            chartArea2.Name = "ChartArea1";
            this.cht_IdVg.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.cht_IdVg.Legends.Add(legend2);
            this.cht_IdVg.Location = new System.Drawing.Point(492, 71);
            this.cht_IdVg.Name = "cht_IdVg";
            series7.ChartArea = "ChartArea1";
            series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series7.Legend = "Legend1";
            series7.Name = "Vd=0.05V";
            series8.ChartArea = "ChartArea1";
            series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series8.Legend = "Legend1";
            series8.Name = "Vd=1.0V";
            this.cht_IdVg.Series.Add(series7);
            this.cht_IdVg.Series.Add(series8);
            this.cht_IdVg.Size = new System.Drawing.Size(748, 526);
            this.cht_IdVg.TabIndex = 35;
            this.cht_IdVg.Text = "chart2";
            // 
            // cht_CVg
            // 
            chartArea3.Name = "ChartArea1";
            this.cht_CVg.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.cht_CVg.Legends.Add(legend3);
            this.cht_CVg.Location = new System.Drawing.Point(492, 71);
            this.cht_CVg.Name = "cht_CVg";
            series9.ChartArea = "ChartArea1";
            series9.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series9.Legend = "Legend1";
            series9.Name = "C(uF)";
            this.cht_CVg.Series.Add(series9);
            this.cht_CVg.Size = new System.Drawing.Size(748, 526);
            this.cht_CVg.TabIndex = 36;
            this.cht_CVg.Text = "chart3";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(1498, 390);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(59, 18);
            this.label34.TabIndex = 39;
            this.label34.Text = "S/cm^2";
            // 
            // txt_gm
            // 
            this.txt_gm.Location = new System.Drawing.Point(1396, 386);
            this.txt_gm.Name = "txt_gm";
            this.txt_gm.Size = new System.Drawing.Size(96, 29);
            this.txt_gm.TabIndex = 38;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(1255, 390);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(29, 18);
            this.label35.TabIndex = 37;
            this.label35.Text = "gm";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.label37);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Location = new System.Drawing.Point(1249, 438);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(303, 159);
            this.groupBox2.TabIndex = 40;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Parameter Optimization";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(244, 82);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(49, 29);
            this.button1.TabIndex = 41;
            this.button1.Text = "Opt.";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(230, 130);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(63, 18);
            this.label40.TabIndex = 41;
            this.label40.Text = "cm^(-3)";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(128, 126);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(96, 29);
            this.textBox7.TabIndex = 47;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(6, 130);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(116, 18);
            this.label39.TabIndex = 46;
            this.label39.Text = "調整後參數值";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(194, 86);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(38, 18);
            this.label38.TabIndex = 45;
            this.label38.Text = "Volt";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(92, 82);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(96, 29);
            this.textBox6.TabIndex = 44;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(6, 86);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(61, 18);
            this.label37.TabIndex = 43;
            this.label37.Text = "目標Vt";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(6, 42);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(80, 18);
            this.label36.TabIndex = 42;
            this.label36.Text = "調整參數";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "氧化層介電系數",
            "Oxide Thickness",
            "氧化層電荷"});
            this.comboBox1.Location = new System.Drawing.Point(92, 38);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(123, 26);
            this.comboBox1.TabIndex = 41;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1564, 609);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.txt_gm);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.cht_CVg);
            this.Controls.Add(this.cht_IdVg);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.cht_IdVd);
            this.Controls.Add(this.btn);
            this.Controls.Add(this.cbx_Output);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_Vt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbx_MosType);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cht_IdVd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cht_IdVg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cht_CVg)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbx_MosType;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbx_GateMartial;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbx_NPtype;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_Ef;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_Dopant;
        private System.Windows.Forms.TextBox txt_Er;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbx_OxideMaterial;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_Vt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_Parameter4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_Parameter3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_Parameter2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_Parameter1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbx_Output;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btn;
        private System.Windows.Forms.TextBox txt_tox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txt_Qox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataVisualization.Charting.Chart cht_IdVd;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DataVisualization.Charting.Chart cht_IdVg;
        private System.Windows.Forms.DataVisualization.Charting.Chart cht_CVg;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txt_gm;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button button1;
    }
}

