﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final
{
    class MOSFET:MOS
    {
        private double _ChannelLength; //通道長
        private double _ChannelWidth; //通道寬

        public MOSFET(Type.Gate gtype, Type.Oxide otype, Type.Dopant dtype, double OxideThickness, double WellDopant, double Qoxide, double ChannelLength, double ChannelWidth) : base(gtype, otype, dtype, OxideThickness, WellDopant, Qoxide) //建構子
        {
            _ChannelLength = ChannelLength;
            _ChannelWidth = ChannelWidth;
        }

        public override double Id(double Vd, double Vg, double Epsilon, double Ef) //IdVd Chart用
        {
            double un;
            double _Epsilon = 8.854 * Math.Pow(10, -14);
            double Cox = _Epsilon * EpsilonOxide(Epsilon) / _OxideThickness;
            switch (_dtype)
            {
                case Type.Dopant.n:
                    un = 1350;
                    break;
                case Type.Dopant.p:
                    un = 480;
                    break;
                default:
                    un = 0;
                    break;
            }
            double _Vt = Vt(Epsilon, Ef);
            if (_dtype == Type.Dopant.p)
            {
                _Vt = -_Vt;
            }
            if (Vg < _Vt)
            {
                return 0;
            }
            else
            {
                if (Vd < Vg - _Vt)
                {
                    double x = Vg - _Vt - 0.5 * Vd;
                    return un * Cox * _ChannelWidth * Vd * x / _ChannelLength;
                }
                else
                {
                    double x = Vg - _Vt;
                    return 0.5 * un * Cox * _ChannelWidth * x * x / _ChannelLength;
                }
            }
        }
    }
}
