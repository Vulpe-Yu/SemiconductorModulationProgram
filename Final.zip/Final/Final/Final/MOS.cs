﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final
{
    static class Type //材料排序，方便後面讀值
    {
        public enum Gate //閘極材質
        { Unknown = -1, nPolySi = 0, pPolySi = 1, Al = 2, W = 3, Other = 4 };

        public enum Oxide //氧化層材質
        { Unknown = -1, SiO2 = 0, HighK = 1, Other = 2 };

        public enum Dopant //MOS類型
        { Unknown = -1, n = 0, p = 1, Other = 2 };
    }

    abstract class MOS //虛擬類別，供繼承
    {
        protected Type.Gate _gtype; //被繼承的欄位(資料成員)需宣告為 protected
        protected Type.Oxide _otype;
        protected Type.Dopant _dtype;
        protected static double _OxideThickness;  //氧化層厚度
        protected static double _WellDopant;  //基板摻雜濃度
        protected static double _Qoxide;  //預估氧化層電荷

        public MOS(Type.Gate gtype, Type.Oxide otype, Type.Dopant dtype, double OxideThickness, double WellDopant, double Qoxide) //建構子
        {
            _gtype = gtype;
            _otype = otype;
            _dtype = dtype;
            _OxideThickness = OxideThickness;
            _WellDopant = WellDopant;
            _Qoxide = Qoxide;
        }

        public double GateEf(double Ef) //閘極費米能階
        {
            double _GateEf = 0;
            switch (_gtype) //根據閘極材質決定
            {
                case Type.Gate.nPolySi:
                    _GateEf = 4.05; //單位eV
                    break;
                case Type.Gate.pPolySi:
                    _GateEf = 5.1;
                    break;
                case Type.Gate.Al:
                    _GateEf = 4.1;
                    break;
                case Type.Gate.W:
                    _GateEf = 4.55;
                    break;
                default: //非列表內材料
                    _GateEf = Ef;
                    break;
            }
            return _GateEf;
        }

        public double SiEf()  //開放給其他類別使用, 故宣告成 public
        {
            double ni = Math.Pow(10, 10); //單位cm^(-3)
            double kT = 0.0259; //單位Volt
            double Ei = 4.61; //單位eV
            double SiEf;
            switch(_dtype) //根據Well摻雜類型決定
            {
                case Type.Dopant.n: //nMOS為pWell
                    SiEf = kT * Math.Log(_WellDopant / ni, Math.E) + Ei;
                    break;
                case Type.Dopant.p: //pMOS為nWell
                    SiEf = -kT * Math.Log(_WellDopant / ni, Math.E) + Ei;
                    break;
                default:
                    SiEf = 0;
                    break;
            }
            return SiEf;
        }

        public double Phims(double Ef)  //WorkFunction
        {
            return GateEf(Ef) - SiEf();
        }

        public double Phib(double Ef)  //Ei - Ef
        {
            double ni = Math.Pow(10, 10); //單位cm^(-3)
            double kT = 0.0259; //單位Volt
            switch (_dtype) //根據Well摻雜類型決定
            {
                case Type.Dopant.n: //nMOS為pWell
                    return kT * Math.Log(_WellDopant / ni, Math.E);
                case Type.Dopant.p: //pMOS為nWell
                    return -kT * Math.Log(_WellDopant / ni, Math.E);
                default:
                    return 0;
            }
        }

        public double EpsilonOxide(double Epsilon) //閘極費米能階
        {
            double _EpsilonOxide = 0;
            switch (_otype) //根據閘極材質決定
            {
                case Type.Oxide.SiO2:
                    _EpsilonOxide = 3.9; //相對介電系數
                    break;
                default: //非列表內材料
                    _EpsilonOxide = Epsilon;
                    break;
            }
            return _EpsilonOxide;
        }

        public double DepletionWidth(double Ef) //空乏區寬度
        {
            double EpsilonSi = 11.7;
            double _Epsilon = 8.854 * Math.Pow(10, -14);
            double q = 1.6 * Math.Pow(10, -19);
            double W;
            switch (_dtype) //根據Well摻雜類型決定
            {
                case Type.Dopant.n: //nMOS為pWell
                    W = 4 * _Epsilon * EpsilonSi * Phib(Ef) / q / _WellDopant;
                    break;
                case Type.Dopant.p: //pMOS為nWell
                    W = -4 * _Epsilon * EpsilonSi * Phib(Ef) / q / _WellDopant;
                    break;
                default:
                    W = 0;
                    break;
            }
            return Math.Pow(W, 0.5);
        }

        public double Vt(double Epsilon, double Ef)
        {
            double _Epsilon = 8.854 * Math.Pow(10, -14);
            double q = 1.6 * Math.Pow(10, -19);
            double Qsc;
            switch (_dtype) //根據Well摻雜類型決定
            {
                case Type.Dopant.n: //nMOS為pWell
                    Qsc = -q * _WellDopant * DepletionWidth(Ef);
                    break;
                case Type.Dopant.p: //pMOS為nWell
                    Qsc = q * _WellDopant * DepletionWidth(Ef);
                    break;
                default:
                    Qsc = 0;
                    break;
            }
            return 2 * Phib(Ef) + Phims(Ef) - Qsc * _OxideThickness / EpsilonOxide(Epsilon) / _Epsilon - _Qoxide * _OxideThickness / EpsilonOxide(Epsilon) / _Epsilon;
        }

        public double TestVfb(double Epsilon, double Ef)
        {
            double _Epsilon = 8.854 * Math.Pow(10, -14);
            double Cox = _Epsilon * EpsilonOxide(Epsilon) / _OxideThickness;
            return Phims(Ef) - _Qoxide / Cox;
        }

        public double TestVd(double Epsilon, double Ef)
        {
            double _Epsilon = 8.854 * Math.Pow(10, -14);
            double q = 1.6 * Math.Pow(10, -19);
            double Cox = _Epsilon * EpsilonOxide(Epsilon) / _OxideThickness;
            double Qsc;
            switch (_dtype) //根據Well摻雜類型決定
            {
                case Type.Dopant.n: //nMOS為pWell
                    Qsc = -q * _WellDopant * DepletionWidth(Ef);
                    break;
                case Type.Dopant.p: //pMOS為nWell
                    Qsc = q * _WellDopant * DepletionWidth(Ef);
                    break;
                default:
                    Qsc = 0;
                    break;
            }
            return -Qsc / Cox;
        }

        public double TestVr(double Ef)
        {
            return 2 * Phib(Ef);
        }

        public double TestQoxCox(double Epsilon)
        {
            double _Epsilon = 8.854 * Math.Pow(10, -14);
            double Cox = _Epsilon * EpsilonOxide(Epsilon) / _OxideThickness;
            return - _Qoxide / Cox;
        }

        public abstract double Id(double Vd, double Vg, double Epsilon, double Ef);

        public double CVg(double Epsilon, double Ef, double Vg) //For C-Vg Plot
        {
            double _Epsilon = 8.854 * Math.Pow(10, -14);
            double q = 1.6 * Math.Pow(10, -19);
            double Cox = _Epsilon * EpsilonOxide(Epsilon) / _OxideThickness;
            double EpsilonSi = 11.7;
            double dum = q * _WellDopant * EpsilonSi * _Epsilon * Math.Pow(_OxideThickness, 2);
            double num = 2 * Math.Pow(EpsilonOxide(Epsilon), 2) * Math.Pow(_Epsilon, 2) * Vg;
            if ((_dtype == Type.Dopant.n && 1 + num / dum > 0) || (_dtype == Type.Dopant.p && 1 - num / dum > 0))
            {
                switch (_dtype) //根據Well摻雜類型決定
                {
                    case Type.Dopant.n: //nMOS為pWell
                        if (Vg > Vt(Epsilon, Ef))
                            return Cox;
                        else
                        {
                            dum = Math.Sqrt(1 + num / dum);
                            break;
                        }
                    case Type.Dopant.p: //pMOS為nWell
                        if (Vg < Vt(Epsilon, Ef))
                            return Cox;
                        else
                        {
                            dum = Math.Sqrt(1 - num / dum);
                            break;
                        }
                    default:
                        dum = 0;
                        break;
                }
                if (dum == 0)
                    return Cox;
                else
                    return Cox / dum;
            }
            else
                return Cox;
        }

        public double OptQox(double Epsilon, double Ef, double Target)
        {
            double QoxOnCox = TestVr(Ef) + TestVd(Epsilon, Ef) + Phims(Ef) - Target;
            double _Epsilon = 8.854 * Math.Pow(10, -14);
            double Cox = _Epsilon * EpsilonOxide(Epsilon) / _OxideThickness;
            double Qox = QoxOnCox * Cox;
            return Qox;
        }

        public double OptCox(double Epsilon, double Ef, double Target)
        {
            double QOnCox = TestVr(Ef) + Phims(Ef) - Target;
            double _Epsilon = 8.854 * Math.Pow(10, -14);
            double q = 1.6 * Math.Pow(10, -19);
            double Qsc;
            switch (_dtype) //根據Well摻雜類型決定
            {
                case Type.Dopant.n: //nMOS為pWell
                    Qsc = -q * _WellDopant * DepletionWidth(Ef);
                    break;
                case Type.Dopant.p: //pMOS為nWell
                    Qsc = q * _WellDopant * DepletionWidth(Ef);
                    break;
                default:
                    Qsc = 0;
                    break;
            }
            double Q = _Qoxide + Qsc;
            double Cox = Q / QOnCox;
            return Cox;
        }

        public double Opttox(double Epsilon, double Ef, double Target)
        {
            double Cox = OptCox(Epsilon, Ef, Target);
            double _Epsilon = 8.854 * Math.Pow(10, -14);
            double tox = _Epsilon * EpsilonOxide(Epsilon) / Cox;
            return tox;
        }

        public double OptErox(double Epsilon, double Ef, double Target)
        {
            double Cox = OptCox(Epsilon, Ef, Target);
            double _Epsilon = 8.854 * Math.Pow(10, -14);
            double Erox = Cox * _OxideThickness / _Epsilon;
            return Erox;
        }
    }
}
