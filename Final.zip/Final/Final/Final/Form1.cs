﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Windows.Forms.DataVisualization.Charting;
using System.IO.Ports;

namespace Final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        MOS IC;
        private Type.Gate gtype;
        private Type.Oxide otype;
        private Type.Dopant dtype;

        private void cbx_MosType_SelectedIndexChanged(object sender, EventArgs e)
        {
            string type = cbx_MosType.SelectedItem.ToString();
            switch (type)
            {
                case "MOSFET":
                    label11.Text = "Channel Length";
                    label12.Text = "Channel Width";
                    label13.Visible = false;
                    label14.Visible = false;
                    label21.Visible = false;
                    txt_Parameter3.Visible = false;
                    txt_Parameter4.Visible = false;
                    break;
                case "FinFET":
                    label11.Text = "Fin Height";
                    label12.Text = "Fin Width";
                    label13.Visible = true;
                    label14.Visible = true;
                    label21.Visible = true;
                    txt_Parameter3.Visible = true;
                    txt_Parameter4.Visible = true;
                    break;                
                default:
                    break;

            }
        }

        private void cbx_NPtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            string type = cbx_NPtype.SelectedItem.ToString();
            switch(type)
            {
                case "N Type":
                    dtype = Type.Dopant.n;
                    break;
                case "P Type":
                    dtype = Type.Dopant.p;
                    break;
                default:
                    break;
            }
        }

        private void cbx_GateMartial_SelectedIndexChanged(object sender, EventArgs e)
        {
            string type = cbx_GateMartial.SelectedItem.ToString();
            double Ef;
            bool Modified = false;
            txt_Ef.Enabled = false;
            switch (type)
            {
                case "nPolySi":
                    gtype = Type.Gate.nPolySi;
                    Ef = 4.05;
                    break;
                case "pPolySi":
                    gtype = Type.Gate.pPolySi;
                    Ef = 5.05;
                    break;
                case "Al":
                    gtype = Type.Gate.Al;
                    Ef = 4.1;
                    break;
                case "W":
                    gtype = Type.Gate.W;
                    Ef = 4.55;
                    break;
                case "Other":
                    gtype = Type.Gate.Other;
                    Ef = 0;
                    Modified = true;
                    break;
                default:
                    Ef = 0;
                    Modified = true;
                    break;
            }
            txt_Ef.Text = Ef.ToString();
            if (Modified)
            {
                txt_Ef.Enabled = true;
                txt_Ef.Clear();
            }
        }

        private void cbx_OxideMaterial_SelectedIndexChanged(object sender, EventArgs e)
        {
            string type = cbx_OxideMaterial.SelectedItem.ToString();
            double Er;
            bool Modified = false;
            txt_Er.Enabled = false;
            switch (type)
            {
                case "SiO2":
                    otype = Type.Oxide.SiO2;
                    Er = 3.9;
                    break;
                case "HighK":
                    otype = Type.Oxide.HighK;
                    Er = 0;
                    Modified = true;
                    break;
                case "Other":
                    otype = Type.Oxide.Other;
                    Er = 0;
                    Modified = true;
                    break;
                default:
                    Er = 0;
                    Modified = true;
                    break;
            }
            txt_Er.Text = Er.ToString();
            if (Modified)
            {
                txt_Er.Enabled = true;
                txt_Er.Clear();
            }
        }

        private void Build() //讀入參數並使用建構子建立元件
        {
            string type = cbx_MosType.SelectedItem.ToString();
            double Dopant;
            string[] input = txt_Dopant.Text.Split('*','^');
            Dopant = double.Parse(input[0]) * Math.Pow(double.Parse(input[1]), double.Parse(input[2]));
            switch (type)
            {
                case "MOSFET":
                    IC = new MOSFET(gtype, otype, dtype, double.Parse(txt_tox.Text) * Math.Pow(10, -7), Dopant, double.Parse(txt_Qox.Text) * Math.Pow(10, -6), double.Parse(txt_Parameter1.Text) * Math.Pow(10, -7), double.Parse(txt_Parameter2.Text) * Math.Pow(10, -7));
                    break;
                case "FinFET":
                    IC = new FinFET(gtype, otype, dtype, double.Parse(txt_tox.Text) * Math.Pow(10, -7), Dopant, double.Parse(txt_Qox.Text) * Math.Pow(10, -6), double.Parse(txt_Parameter2.Text) * Math.Pow(10, -7), double.Parse(txt_Parameter1.Text) * Math.Pow(10, -7), double.Parse(txt_Parameter3.Text), double.Parse(txt_Parameter4.Text) * Math.Pow(10, -7));
                    break;
                default:
                    break;
            }
        }

        private void btn_Click(object sender, EventArgs e)
        {
            Build();
            txt_Vt.Text = IC.Vt(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text)).ToString();
            textBox1.Text = IC.TestVfb(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text)).ToString();
            textBox2.Text = IC.TestVd(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text)).ToString();
            textBox3.Text = IC.TestVr(double.Parse(txt_Ef.Text)).ToString();
            textBox4.Text = IC.Phims(double.Parse(txt_Ef.Text)).ToString();
            textBox5.Text = IC.TestQoxCox(double.Parse(txt_Er.Text)).ToString();
            string output = cbx_Output.SelectedItem.ToString();
            switch (output)
            {
                case "Id-Vd":
                    cht_IdVg.Visible = false;
                    cht_CVg.Visible = false;
                    cht_IdVd.Visible = true;
                    IdVdPlot();
                    break;
                case "Id-Vg":
                    cht_IdVd.Visible = false;
                    cht_CVg.Visible = false;
                    cht_IdVg.Visible = true;
                    IdVgPolt();
                    break;
                case "C-Vg":
                    cht_IdVd.Visible = false;
                    cht_CVg.Visible = true;
                    cht_IdVg.Visible = false;
                    CVgPolt();
                    break;
                default:
                    break;
            }
        }

        private void IdVdPlot()
        {
            //Clear
            for (int i = 0; i < 6; i++)
            {
                cht_IdVd.Series[i].Points.Clear();
            }
            //SetChartArea
            ChartArea area_1 = new ChartArea("ViewArea");
            switch (dtype)
            {
                case Type.Dopant.n:
                    area_1.AxisX.Minimum = -0.5; //X軸數值起點
                    break;
                case Type.Dopant.p:
                    area_1.AxisX.Minimum = -3; //X軸數值起點
                    break;
                default:
                    break;
            }
            area_1.AxisY.Minimum = 0; //Y軸數值起點
            area_1.AxisY.Maximum = 20; //Y軸數值終點
            area_1.AxisX.ScaleView.Size = 3.5; //設定視窗範圍內一開始顯示多少點
            area_1.AxisX.Interval = 0.5; //設定格線間隔
            area_1.AxisY.Interval = 5;
            area_1.AxisX.IntervalAutoMode = IntervalAutoMode.FixedCount;
            area_1.AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.All; //設定scrollbar
            cht_IdVd.ChartAreas[0] = area_1; //將設定好的ChartArea放進Chart
            cht_IdVd.ChartAreas[0].AxisY.Title = "Id (A/cm^2)";
            cht_IdVd.ChartAreas[0].AxisX.Title = "Vd (V)";
            //PointsSetting
            string type = cbx_MosType.SelectedItem.ToString();
            double Area;
            switch (type)
            {
                case "MOSFET":
                    Area = double.Parse(txt_Parameter2.Text) * IC.DepletionWidth(double.Parse(txt_Ef.Text));
                    break;
                case "FinFET":
                    Area = 2 * double.Parse(txt_Parameter1.Text) * IC.DepletionWidth(double.Parse(txt_Ef.Text));
                    break;
                default:
                    Area = 0;
                    break;
            }
            for (int i = 0; i < 6; i++)
            {
                double Id;
                double Vg = (i + 1) * 0.5;
                for (double Vd = 0; Vd < 3; Vd += 0.05)
                {
                    Id =  IC.Id(Vd, Vg, double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text));
                    Id = Id / Area;
                    if (dtype == Type.Dopant.n)
                    {
                        cht_IdVd.Series[i].Points.AddXY(Vd, Id);
                    }
                    if (dtype == Type.Dopant.p)
                    {
                        cht_IdVd.Series[i].Points.AddXY(-Vd, Id);
                    }
                }
            }
        }

        private void IdVgPolt()
        {
            //Clear
            for (int i = 0; i < 2; i++)
            {
                cht_IdVg.Series[i].Points.Clear();
            }
            //SetChartArea
            ChartArea area_1 = new ChartArea("ViewArea");
            switch (dtype)
            {
                case Type.Dopant.n:
                    area_1.AxisX.Minimum = 0; //X軸數值起點
                    break;
                case Type.Dopant.p:
                    area_1.AxisX.Minimum = -5; //X軸數值起點
                    break;
                default:
                    break;
            }
            area_1.AxisY.Minimum = 0; //Y軸數值起點
            area_1.AxisY.Maximum = 3; //Y軸數值終點
            area_1.AxisX.ScaleView.Size = 5; //設定視窗範圍內一開始顯示多少點
            area_1.AxisX.Interval = 1; //設定格線間隔
            area_1.AxisY.Interval = 0.5;
            area_1.AxisX.IntervalAutoMode = IntervalAutoMode.FixedCount;
            area_1.AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.All; //設定scrollbar
            cht_IdVg.ChartAreas[0] = area_1; //將設定好的ChartArea放進Chart
            cht_IdVg.ChartAreas[0].AxisY.Title = "Id (A/cm^2)";
            cht_IdVg.ChartAreas[0].AxisX.Title = "Vg (V)";
            //PointsSetting
            string type = cbx_MosType.SelectedItem.ToString();
            double Area;
            switch (type)
            {
                case "MOSFET":
                    Area = double.Parse(txt_Parameter2.Text) * IC.DepletionWidth(double.Parse(txt_Ef.Text));
                    break;
                case "FinFET":
                    Area = 2 * double.Parse(txt_Parameter1.Text) * IC.DepletionWidth(double.Parse(txt_Ef.Text));
                    break;
                default:
                    Area = 0;
                    break;
            }
            double gm = 0;
            double Id;
            double Vd = 0.05;
            for (double Vg = 0; Vg < 5; Vg += 0.01)
            {
                Id = IC.Id(Vd, Vg, double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text));
                Id = Id / Area;
                if (dtype == Type.Dopant.n)
                {
                    cht_IdVg.Series[0].Points.AddXY(Vg, Id);
                }
                if (dtype == Type.Dopant.p)
                {
                    cht_IdVg.Series[0].Points.AddXY(-Vg, Id);
                }
            }
            Vd = 1;
            for (double Vg = 0; Vg < 5; Vg += 0.05)
            {
                Id = IC.Id(Vd, Vg, double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text));
                Id = Id / Area;
                if (dtype == Type.Dopant.n)
                {
                    cht_IdVg.Series[1].Points.AddXY(Vg, Id);
                }
                if (dtype == Type.Dopant.p)
                {
                    cht_IdVg.Series[1].Points.AddXY(-Vg, Id);
                }
                double temp = Math.Abs((Id - IC.Id(Vd, Vg - 0.05, double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text))) / 0.05);
                if (temp > gm)
                    gm = temp;
            }
            txt_gm.Text = gm.ToString();
        }
        
        private void CVgPolt()
        {
            //Clear
            cht_CVg.Series[0].Points.Clear();
            //SetChartArea
            double start = 0;
            double end = 0;
            if (dtype == Type.Dopant.n)
            {
                start = IC.TestVfb(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text)) - 0.1;
                end = IC.Vt(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text)) + 0.1;
            }
            if (dtype == Type.Dopant.p)
            {
                start = IC.Vt(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text)) - 0.1;
                end = IC.TestVfb(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text)) + 0.1;
            }
            double Xmin = Math.Floor(start * 10) / 10;
            double Xmax = (Math.Ceiling(end * 100) + 1) / 100;
            start = Xmin;
            end = Xmax;
            // 設定ChartArea
            ChartArea area_1 = new ChartArea("ViewArea");
            area_1.AxisX.Minimum = Xmin; //X軸數值起點
            area_1.AxisY.Minimum = 0; //Y軸數值起點
            area_1.AxisY.Maximum = 5; //Y軸數值終點
            area_1.AxisX.ScaleView.Size = Xmax - Xmin; //設定視窗範圍內顯示多少點
            area_1.AxisX.Interval = 0.2; //設定格線間隔
            area_1.AxisY.Interval = 1;
            area_1.AxisX.IntervalAutoMode = IntervalAutoMode.FixedCount;
            area_1.AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.All; //設定scrollbar
            cht_CVg.ChartAreas[0] = area_1; //將設定好的ChartArea放進Chart
            cht_CVg.ChartAreas[0].AxisY.Title = "C (uF)";
            cht_CVg.ChartAreas[0].AxisX.Title = "Vg (V)";
            //PointsSetting
            double C;
            if (dtype == Type.Dopant.n)
            {
                for (double Vg = start; Vg <= end; Vg += 0.005)
                {
                    C = IC.CVg(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text), Vg - IC.TestVfb(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text)));
                    cht_CVg.Series[0].Points.AddXY(Vg, C / Math.Pow(10, -6));
                }
            }
            if (dtype == Type.Dopant.p)
            {
                for (double Vg = start; Vg <= end; Vg += 0.005)
                {
                    C = IC.CVg(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text), Vg - IC.TestVfb(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text)));
                    cht_CVg.Series[0].Points.AddXY(Vg, C / Math.Pow(10, -6));
                }
            }
        }

        private void Optimization()
        { 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Build();
            switch (comboBox1.SelectedItem.ToString())
            {
                case "閘極Fermi level":
                    break;
                case "Well Dopant":
                    break;
                case "氧化層介電系數":
                    double Erox = IC.OptErox(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text), double.Parse(textBox6.Text));
                    textBox7.Text = Erox.ToString();
                    break;
                case "Oxide Thickness":
                    double tox = IC.Opttox(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text), double.Parse(textBox6.Text));
                    textBox7.Text = tox.ToString();
                    break;
                case "氧化層電荷":
                    double Qox = IC.OptQox(double.Parse(txt_Er.Text), double.Parse(txt_Ef.Text), double.Parse(textBox6.Text));
                    textBox7.Text = Qox.ToString();
                    break;
                default:
                    break;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedItem.ToString())
            {
                case "閘極Fermi level":
                    label40.Text = "eV";
                    break;
                case "Well Dopant":
                    label40.Text = "cm^(-3)";
                    break;
                case "氧化層介電系數":
                    label40.Text = " ";
                    break;
                case "Oxide Thickness":
                    label40.Text = "nm";
                    break;
                case "氧化層電荷":
                    label40.Text = "uC";
                    break;
                default:
                    label40.Text = " ";
                    break;
            }
        }
    }
}
