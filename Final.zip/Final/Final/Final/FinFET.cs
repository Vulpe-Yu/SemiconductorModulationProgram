﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final
{
    class FinFET:MOS
    {
        private double _FinWidth; //Fin寬度
        private double _FinHeight; //Fin高度
        private double _FinNum; //Fin個數
        private double _GateLength; //Gap - double Spacer, Equal to Channel Length

        public FinFET(Type.Gate gtype, Type.Oxide otype, Type.Dopant dtype, double OxideThickness, double WellDopant, double Qoxide, double FinWidth, double FinHeight, double FinNum, double GateLength) : base(gtype, otype, dtype, OxideThickness, WellDopant, Qoxide) //建構子
        {
            _FinWidth = FinWidth;
            _FinHeight = FinHeight;
            _FinNum = FinNum;
            _GateLength = GateLength;
        }

        public double ChannalWidth() //通道寬
        {
            return 2 * _FinHeight * _FinNum;
        }

        public override double Id(double Vd, double Vg, double Epsilon, double Ef) //IdVd Chart用
        {
            double un;
            double _Epsilon = 8.854 * Math.Pow(10, -14);
            double Cox = _Epsilon * EpsilonOxide(Epsilon) / _OxideThickness;
            switch (_dtype)
            {
                case Type.Dopant.n:
                    un = 1350;
                    break;
                case Type.Dopant.p:
                    un = 480;
                    break;
                default:
                    un = 0;
                    break;
            }
            double _Vt = Vt(Epsilon, Ef);
            if (_dtype == Type.Dopant.p)
            {
                _Vt = -_Vt;
            }
            if (Vg < _Vt)
            {
                return 0;
            }
            else
            {
                if (Vd < Vg - _Vt)
                {
                    double x = Vg - _Vt - 0.5 * Vd;
                    return un * Cox * ChannalWidth() * Vd * x / _GateLength;
                }
                else
                {
                    double x = Vg - _Vt;
                    return 0.5 * un * Cox * ChannalWidth() * x * x / _GateLength;
                }
            }
        }
    }
}
